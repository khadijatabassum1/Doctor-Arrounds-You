package com.appointmentapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText user, pass;
    Button log;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Boolean savelogin;
    
    CheckBox savelogincheckbox;


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        user = (EditText) findViewById(R.id.email);
        pass = (EditText) findViewById(R.id.Userpassword);
        log = (Button) findViewById(R.id.login);


        sharedPreferences = getSharedPreferences("loginref", MODE_PRIVATE);

        savelogincheckbox = (CheckBox) findViewById(R.id.check);
        editor = sharedPreferences.edit();
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWelcome();
                login();

            }

        });
        savelogin=sharedPreferences.getBoolean("savelogin",true);
        if(savelogin==true)
        {
            user.setText(sharedPreferences.getString("username",null));
            user.setText(sharedPreferences.getString("password",null));
        }
    }

    private void openWelcome() {
//        Intent intent;
//        intent = new Intent(this,Welcome.class);
//
//        startActivity(intent);
    }

    public  void login()
{
    String useranme = user.getText().toString();
    String password = user.getText().toString();
                 if(useranme.equals("")&&password.equals(""))

    {

        Toast.makeText(this, "user name and password is matched!", Toast.LENGTH_LONG).show();
        if (savelogincheckbox.isChecked()) {
            editor.putBoolean("savelogin", true);
            editor.putString("username", useranme);
            editor.putString("password", password);
            editor.commit();
        }
    }else

    {
        Toast.makeText(this, "error", Toast.LENGTH_LONG).show();

    }
}

}
/*
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.login);

    final EditText user = (EditText) findViewById(R.id.userName);
    final EditText pass = (EditText) findViewById(R.id.pass);
    final Button log= (Button) findViewById(R.id.log);
    final Button  sign_up= (Button) findViewById(R.id.sign_up);

    log.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String userName = user.getText().toString();
            String password = pass.getText().toString();
            SharedPreferences preferences = getSharedPreferences("MYPREFS", MODE_PRIVATE);

            //String savedPassword = preferences.getString(password, "");
            //String savedUserName = preferences.getString(user, "");

            String userDetails = preferences.getString(user + password + "data","No information on that user.");
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("display",userDetails);
            editor.commit();

            Intent displayScreen = new Intent(login.this, signUp.class);
            startActivity(displayScreen);
        }
    });


    sign_up.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent registerScreen = new Intent(login.this, signUp.class);
            startActivity(registerScreen);
        }
    });
}



}
*/

