package com.appointmentapp;

/**

 */

public class DoctorModel {

        private String doc_name,doc_exp,speciality;


    public DoctorModel(String doc_name, String doc_exp, String speciality) {
            this.doc_name = doc_name;
            this.doc_exp = doc_exp;
            this.speciality=  speciality;
        }


    public String getDoc_name() {
        return doc_name;
    }

    public void setDoc_name(String doc_name) {
        this.doc_name = doc_name;
    }

    public String getDoc_exp() {
        return doc_exp;
    }

    public void setDoc_exp(String doc_exp) {
        this.doc_exp = doc_exp;
    }


    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }
}

