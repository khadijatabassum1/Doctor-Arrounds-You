package com.appointmentapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
    private Button loginButton;
    private Button signupButton;
    private Button search_doc,first_aid;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loginButton=(Button)findViewById(R.id.login);

        signupButton=(Button)findViewById(R.id.signup);
        search_doc = findViewById(R.id.search_doc);
        first_aid = findViewById(R.id.first_aid);

    }


    @Override
    protected void onStart() {
        super.onStart();

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,login.class);

                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,signUp.class);

                startActivity(intent);
            }
        });

//        search_doc.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,SearDoctors.class);
//
//                startActivity(intent);
//            }
//        });
//
//        first_aid.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,FirstAddContact.class);
//
//                startActivity(intent);
//            }
//        });


    }


}
