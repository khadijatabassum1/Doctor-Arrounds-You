package ifc;

import android.view.View;

/**
 * Created by Hafiz Haseeem on 8/29/2017.
 */

public interface OnItemClickListener {

    public void onItemClick(final View view, final int cardposition);


}
