package ifc;

import android.content.DialogInterface;

/**
 * Created by Haseee on 4/11/2018.
 */

public interface MyDialogCloseListener {

    public void handleDialogClose(DialogInterface dialog);
}
